#include "modify.h"

extern Stations g_stations;
extern Citys g_citys;
extern Graph g_graph;
extern int trainID_expire[MAX_TRAIN_ID];
extern int trainID_vis[MAX_TRAIN_ID];

int findCity(char *c_name) {
    if (c_name == NULL) {
        ///printf("[modify.c][findCity][Error]: c_name is NULL\n");
        return -1;
    }
    int res = find_city_name(c_name);
    if (res > 0) 
        return res; // If the city is found, return its ID
    return 0; // not found
}

int findStation(char *s_name) {
    if (s_name == NULL) {
        ///printf("[modify.c][findStation][Error]: s_name is NULL\n");
        return -1;
    }
    int res = find_station_name(s_name);
    if (res > 0) 
        return res; // If the station is found, return its ID
    return 0; // not found
}

int insertStation(char *s_name, char *c_name) {
    if (s_name == NULL || c_name == NULL) {
        ///printf("[modify.c][insertStation][Error]: s_name or c_name is NULL\n");
        return -1;
    }

    int city_id = findCity(c_name);
    if (city_id <= 0) {// city not found or error
        ///printf("[modify.c][insertStation][Error]: City '%s' not found\n", c_name);
        return -1;
    }

    int station_id = findStation(s_name);
    if (station_id > 0) {
        if (g_stations.st[station_id].expire) {
            // If the station is expired, we can reuse it
            g_stations.st[station_id].expire = 0; // mark as not expired
            ///printf("[modify.c][insertStation][INFO]: Reusing expired station '%s' with ID %d\n", s_name, station_id);
            return station_id; // return the existing station ID
        } else {
            ///printf("[modify.c][insertStation][INFO]: Station '%s' already exists and is not expired\n", s_name);
            return 0; // already exists and not expired
        }
    }
        
    station_id = insert_station_name(s_name);
    // ///printf("[modify.c][insertStation][INFO]: Inserting station '%s' with ID %d in city '%s'\n", s_name, station_id, c_name);
    if (station_id <= 0) {
        ///printf("[modify.c][insertStation][Error]: Failed to insert station '%s'\n", s_name);
        return -1; // insertion failed
    }
    // Create a new station
    if (g_stations.station_count >= MAX_STATIONS) {
        ///printf("[modify.c][insertStation][Error]: No space for new station '%s'\n", s_name);
        return -1; // no space for new station
    }
    Station *new_station = &g_stations.st[g_stations.station_count++];
    new_station->expire = 0; // not expired
    new_station->train_count = 0; // no trains yet
    new_station->nodes = NULL; // no nodes yet
    ///printf("[modify.c][insertStation][INFO]: New station '%s' created with ID %d in city '%s'\n", s_name, station_id, c_name);
    
    g_citys.citys[city_id].st_ids[g_citys.citys[city_id].st_count] = station_id; // add station ID to city's list
    g_citys.citys[city_id].st_count++;
    return station_id; // success, new station created
}

int insertCity(char *c_name) {
    if (c_name == NULL) {
        ///printf("[modify.c][insertCity][Error]: c_name is NULL\n");
        return -1;
    }
    int city_id = findCity(c_name);
    if (city_id > 0) {
        ///printf("[modify.c][insertCity][INFO]: City '%s' already exists with ID %d\n", c_name, city_id);
        return 0; // already exists
    }
    city_id = insert_city_name(c_name);
    if (city_id <= 0) {
        ///printf("[modify.c][insertCity][Error]: Failed to insert city '%s'\n", c_name);
        return -1; // insertion failed
    }
    // Create a new city
    if (g_citys.city_count >= MAX_CITYS) {
        ///printf("[modify.c][insertCity][Error]: No space for new city '%s'\n", c_name);
        return -1; // no space for new city
    }
    City *new_city = &g_citys.citys[g_citys.city_count++];
    new_city->st_count = 0; // no stations yet
    ///printf("[modify.c][insertCity][INFO]: New city '%s' created with ID %d\n", c_name, city_id);
    return city_id; // success, new city created
}


/*
增加火车车次，先字符串查找车次（train_id）是否已经存在。如果存在且 `expire == 1`，则将该车次的 `expire` 赋为 0；如果 `expire == 0` 返回增加失败，信息为已经存在。
如果不存在，要求按格式输入：
第一行车站数 n，接下来一行 n 个字符串表示车站名，
必须都已经存在，接下来 n-1 行每行依次输入，
第 i 站到第 i+1 站这段的 出发时间(HH:MM)，到达时间(HH:MM)，票价（两位小数）。
然后根据输入的信息插入。
下面这个函数是专为插入情况调用。
将字符串 train_id 转化为整数 train_id 的方法：
如果纯四位数字，直接化为五位整数
其余均为字母开头，格式为 [character][number]，
其中如果number 不足四位，前面补零。
字母变成数字规则如下：c->1 d->2 g->3 k->4 t-> 5 y->6 z->7

如 C123 -> 10123, D1012 -> 21012
G3 ->30003, T33->50033。

字母只会出现这几种。
变成数字之后，
在extern int trainID_expire 数组中查询是否过期
在extern int trainID_vis 数组中查询是否已经存在。
如果要插入的车次存在且已经过期，则将其 `expire` 赋为 0。
如果要插入的车次存在且没有过期，则返回 0，表示已经存在。
如果要插入的车次不存在，则将 vis 赋为1, expire 赋为 0。
函数实现：
*/
static int train_str_to_id(const char *train_id) {
    if (!train_id) {
        ///printf("[modify.c][train_str_to_id][Error]: train_id is NULL\n");
        return -1;
    }
    int len = strlen(train_id);
    int id = 0;
    if (len == 4 && isdigit(train_id[0]) && isdigit(train_id[1]) && isdigit(train_id[2]) && isdigit(train_id[3])) {
        id = atoi(train_id);
    } else if (isalpha(train_id[0])) {
        int prefix = 0;
        switch (tolower(train_id[0])) {
            case 'c': prefix = 1; break;
            case 'd': prefix = 2; break;
            case 'g': prefix = 3; break;
            case 'k': prefix = 4; break;
            case 't': prefix = 5; break;
            case 'y': prefix = 6; break;
            case 'z': prefix = 7; break;
            default: return -1;
        }
        char numbuf[8] = {0};
        int numlen = len - 1;
        if (numlen > 4) return -1;
        strncpy(numbuf, train_id + 1, numlen);
        for (int i = 0; i < numlen; ++i) {
            if (!isdigit(numbuf[i])) return -1;
        }
        char numstr[5] = {0};
        int fill = 4 - numlen;
        for (int i = 0; i < fill; ++i) numstr[i] = '0';
        strcpy(numstr + fill, numbuf);
        id = prefix * 10000 + atoi(numstr);
    } else {
        ///printf("[modify.c][train_str_to_id][Error]: Invalid train_id format '%s'\n", train_id);
        return -1;
    }
    if (id <= 0 || id >= MAX_TRAIN_ID) {
        ///printf("[modify.c][train_str_to_id][Error]: train_id out of range: %d\n", id);
        return -1;
    }
    return id;
}

int insertTrain(char *train_id, int n, char **st_names, TimeType *t_arr, TimeType *t_depart, double *price) {
    if (!train_id || n <= 1 || !st_names || !t_arr || !t_depart || !price) {
        ///printf("[modify.c][insertTrain][Error]: Invalid parameters\n");
        return -1;
    }
    int id = train_str_to_id(train_id);
    if (id == -1) {
        ///printf("[modify.c][insertTrain][Error]: Invalid train_id '%s'\n", train_id);
        return -1;
    }

    if (trainID_vis[id]) {
        if (trainID_expire[id]) {
            ///printf("[modify.c][insertTrain][INFO]: Reusing expired train_id %d\n", id);
            trainID_expire[id] = 0; // 恢复
            return id;
        } else {
            ///printf("[modify.c][insertTrain][INFO]: Train_id %d already exists and is not expired\n", id);
            return 0; // 已存在且未过期
        }
    } else {
        trainID_vis[id] = 1;
        trainID_expire[id] = 0;
        // 插入节点到 g_graph
        int node_ids[n];
        for (int i = 0; i < n; ++i) {
            int s_id = findStation(st_names[i]);
            if (s_id <= 0) {
                ///printf("[modify.c][insertTrain][Error]: Station '%s' not found\n", st_names[i]);
                return -1; // 车站不存在
            }
            TimeType arr = t_arr[i];
            TimeType dep = t_depart[i];
            if (i == 0) arr = dep; // 起点站到达=出发
            if (i == n-1) dep = arr; // 终点站出发=到达
            int node_id = add_node(&g_graph, id, s_id, &arr, &dep);
            if (node_id < 0) {
                ///printf("[modify.c][insertTrain][Error]: Failed to add node for train_id %d at station '%s'\n", id, st_names[i]);
                return -1;
            }
            ///printf("[modify.c][insertTrain][INFO]: Added node %d for train_id %d at station '%s'\n", node_id, id, st_names[i]);
            node_ids[i] = node_id;
            // 挂到车站链表
            NodeList *new_node = (NodeList*)malloc(sizeof(NodeList));
            if (!new_node) {
                ///printf("[modify.c][insertTrain][Error]: Memory allocation failed for new_node\n");
                return -1;
            }
            ///printf("[modify.c][insertTrain][INFO]: Adding node %d to station %d\n", node_id, s_id);
            new_node->node_id = node_id;
            new_node->next = g_stations.st[s_id].nodes;
            g_stations.st[s_id].nodes = new_node;
            g_stations.st[s_id].train_count++;
        }
        // 1. 相邻两站加边
        for (int i = 0; i < n - 1; ++i) {
            ValueType w;
            w.p_time = getTimeInterval(&t_depart[i], &t_arr[i + 1]);
            w.p_cost = (int)(price[i] * 100 + 0.5); // 票价转为分
            add_edge(&g_graph, node_ids[i], node_ids[i + 1], IN, w);
            ///printf("[modify.c][insertTrain][INFO]: Added edge from node %d to node %d with time %d and cost %.2f\n", node_ids[i], node_ids[i + 1], w.p_time, price[i]);
            add_edge(&g_graph, node_ids[i] + DELTA, node_ids[i + 1] + DELTA, IN, w);
            ///printf("[modify.c][insertTrain][INFO]: Added edge from node %d to node %d on layer 2 with time %d and cost %.2f\n", node_ids[i] + DELTA, node_ids[i + 1] + DELTA, w.p_time, price[i]);
        }
        // 2. 同站换乘边
        for (int i = 1; i < n; ++i) { // 起点不加同站换乘边
            int s_id = findStation(st_names[i]);
            int u = node_ids[i];
            NodeList *cur = g_stations.st[s_id].nodes;
            while (cur) {
                int v = cur->node_id;
                if (v != u) {
                    ValueType w1;
                    w1.p_cost = 0;
                    w1.p_time = getTimeInterval(&g_graph.node[v].train_arrive_time, &g_graph.node[u].train_arrive_time);
                    add_edge(&g_graph, u, v+DELTA, CROSS, w1);
                    ///printf("[modify.c][insertTrain][INFO]: Added cross edge from node %d to node %d with time %d\n", u, v + DELTA, w1.p_time);
                    ValueType w2;
                    w2.p_cost = 0;
                    w2.p_time = getTimeInterval(&g_graph.node[u].train_arrive_time, &g_graph.node[v].train_arrive_time);
                    add_edge(&g_graph, v, u+DELTA, CROSS, w2);
                    ///printf("[modify.c][insertTrain][INFO]: Added cross edge from node %d to node %d with time %d\n", v, u + DELTA, w2.p_time);
                }
                cur = cur->next;
            }
        }
        ///printf("[modify.c][insertTrain][INFO]: Train_id %d inserted successfully with %d stations\n", id, n);
        return id;
    }
    ///printf("[modify.c][insertTrain][Error]: Unexpected Error\n");
    return -1; // should not reach here
}

int deleteStation(char *s_name) {
    int s_id = findStation(s_name);
    if (s_id == -1) {
        ///printf("[modify.c][deleteStation][Error]: Unexpected Error\n");
        return -1;
    }
    if (s_id == 0) {
        ///printf("[modify.c][deleteStation][Error]: Station '%s' not found\n", s_name);
        return -1;
    }
    if (g_stations.st[s_id].expire) {
        ///printf("[modify.c][deleteStation][Error]: Station '%s' is already expired\n", s_name);
        return 0;
    }
    g_stations.st[s_id].expire = 1;
    ///printf("[modify.c][deleteStation][INFO]: Station '%s' with ID %d deleted successfully\n", s_name, s_id);
    return 1;
}

int deleteTrain(char *train_id) {
    int id = train_str_to_id(train_id);
    if (id == -1) {
        ///printf("[modify.c][deleteTrain][Error]: Invalid train_id '%s'\n", train_id);
        return -1;
    }
    if (!trainID_vis[id]) {
        ///printf("[modify.c][deleteTrain][Error]: Train_id %d does not exist\n", id);
        return -1; // train does not exist
    }
    if (trainID_expire[id]) {
        ///printf("[modify.c][deleteTrain][Error]: Train_id %d is already expired\n", id);
        return 0; // already expired
    }
    trainID_expire[id] = 1;
    ///printf("[modify.c][deleteTrain][INFO]: Train_id %d deleted successfully\n", id);
    return 1;
}

